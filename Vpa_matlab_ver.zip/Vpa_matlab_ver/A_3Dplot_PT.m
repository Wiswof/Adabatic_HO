close all
% 生成数据
%theta = linspace(0, 4*pi, 1000);

Fnqp=matlabFunction(nqp);
FVpqp=matlabFunction(-Vpqp);
qq=linspace(-0.1, 0.1, 1000);
qq1=linspace(0, 0.1, 1000);
qq2=linspace(-0.08, 0.08, 1000);
% 绘制线1（在xoy平面上）
figure;
plot3( 1+Fnqp(qq),qq,0*qq,'--','LineWidth', 2, 'Color', 'blue')
hold on;


%%
% plot3(1+ Fnqp(qq1),0*qq1,FVpqp(qq1), 'LineWidth', 2, 'Color', 'red');
% % 添加连接线
% for qqi = 1:floor(length(qq1)/21):length(qq1)
%     plot3([1+Fnqp(qq1(qqi)) 1+Fnqp(qq1(qqi))], 0*[qq1(qqi) qq1(qqi)], [0 FVpqp(qq1(qqi))], '--', 'Color', 'red');
% end
%%
plot3(1+ Fnqp(qq),qq,FVpqp(qq), 'LineWidth', 2, 'Color', 'red');
% 添加连接线
for qqi = 1:floor(length(qq2)/24):length(qq2)
    plot3([1+Fnqp(qq2(qqi)) 1+Fnqp(qq2(qqi))], [qq2(qqi) qq2(qqi)], [0 FVpqp(qq2(qqi))], '--', 'Color', 'red');
end

%%

% 设置图形属性
Grap.numfontsize=12;
Grap.fontsize=20;
%title('Two 3D Curves Example with Projection');

grid on;
plot3( [0.98,1],[0,0],[0,0], 'LineWidth', 2, 'Color', 'red')
plot3( [1,1.08],[0,0],[0,0],'-.', 'LineWidth', 2, 'Color', 'c')

view(3);     % 设置视图为三维
% 获取当前轴对象
zlim ([-0.7*10^-4,0])
hold off;
%camva('auto')
ax = gca;
ax.XAxis.FontSize = Grap.numfontsize;
ax.YAxis.FontSize = Grap.numfontsize;
ax.ZAxis.FontSize = Grap.numfontsize;
xlabel('$\frac{n(q_{min})}{n_c}$','Interpreter','latex','FontSize',Grap.fontsize);
ylabel('$\frac{g}{\kappa} q_{min}$','Interpreter','latex','FontSize',Grap.fontsize,'Position',[1.12,0,-0.7*10^-4]);
zlabel('$-\frac{g^2}{\kappa^2}\frac{V_{height}}{\hbar \Omega}$','Interpreter','latex','Rotation',90,'FontSize',Grap.fontsize-3);
%legend('Line in xoy plane', 'Spiral Curve', 'Projection on xoy plane','Location','best');
